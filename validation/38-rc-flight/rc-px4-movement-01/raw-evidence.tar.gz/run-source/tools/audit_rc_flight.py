"""Independent raw RC integrator, native DDS and physical-flight audit.

Never import the product RC integrator or treat the task's success as evidence.
Run in the recorded ROS message overlays to decode actual retained CDR.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path


def require(value, reason):
    if not value:
        raise ValueError(reason)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def lines(path):
    with Path(path).open() as source:
        for line in source:
            require(line.endswith('\n'), 'Incomplete raw record: '+str(path))
            yield json.loads(line)


def physical(row):
    v = row['vehicle']
    return dict(time=row['time'], position=[v[7], v[6], -v[8]], velocity=[v[4], v[3], -v[5]],
                yaw=math.remainder(math.pi/2-v[11], 2*math.pi))


def audit(root):
    root = Path(root)
    result = json.loads((root/'result.json').read_text())
    require(result['status'] == 'observed' and result['safe_landing'] and result['children_reaped']
            and not result['cleanup_errors'] and result['source_unchanged'] and result['candidate_unchanged'],
            'Run/cleanup/identity did not complete')
    for name, checksum in result['source_sha256'].items():
        require(digest(root/'run-source'/name) == checksum, 'Retained source differs: '+name)
    require(result['actual_control_sha256'] == result['admission']['control']['python_sha256'], 'Control install differs')
    events = []
    for line in (root/'control.log').read_text().splitlines():
        start = line.find('{"event":')
        if start >= 0:
            events.append(json.loads(line[start:]))
    require(events and all(a['event_id']+1 == b['event_id'] for a,b in zip(events,events[1:])), 'Incomplete Control event sequence')
    frames, targets, activations, revokes = {}, [], [], []
    target = None
    last_op = None
    stream = None
    for event in events:
        require(event['run_id'] == result['run_id'], 'Foreign event run')
        if event['event'] == 'rc_frame' and event['accepted']:
            frame = json.loads(event['raw'])
            require(frame['source'] == 'wksim-software-rc-v1' and len(frame['channels_us']) == 8,
                    'Wrong RC envelope')
            require(frame['run_id'] == result['run_id'] and frame['control_epoch'] == event['control_epoch'], 'Foreign frame identity')
            require(0 <= event['received_monotonic_ns']-frame['produced_monotonic_ns'] <= 1_500_000_000, 'Accepted stale/future frame')
            frames[(frame['stream_id'], frame['sequence'])] = (frame, event)
        elif event['event'] == 'setup_completed' and event.get('control_state') == 'RC_POS_CONTROL' and not event.get('unchanged'):
            activations.append(event)
            stream = event['rc_stream_id']
            target = list(event['position_enu_m'])+[event['yaw_enu_rad']]
            last_op = None
        elif event['event'] == 'control_revoked':
            revokes.append(event)
            target = None
        elif event['event'] == 'setup_completed' and event.get('control_state') == 'COMMAND_CONTROL':
            target = None
        elif event['event'] == 'rc_integrated':
            require(target is not None and event['stream_id'] == stream, 'RC output without explicit active owner')
            frame, received = frames[(stream, event['sequence'])]
            require(event['publisher_gid'] == received['publisher_gid'], 'RC writer changed')
            dt = event['dt_s']
            require(0 <= dt <= .05 and (dt == 0 if last_op is None else abs(dt-(event['operation_ns']-last_op)/1e9)<1e-10), 'RC integration dt mismatch')
            require(0 <= event['serviced_monotonic_ns']-frame['produced_monotonic_ns'] <= 1_501_000_000,
                    'Expired RC output')
            pwm = frame['channels_us']
            require(all(type(p) is int and 1000 <= p <= 2000 for p in pwm), 'Illegal accepted PWM')
            normalized = []
            for p in pwm[:4]:
                u = (p-1500)/500
                normalized.append(0. if abs(u)<=.05 else math.copysign((abs(u)-.05)/.95, u))
            require(all(abs(a-b)<1e-12 for a,b in zip(normalized,event['normalized'])), 'Deadzone mismatch')
            d = normalized if pwm[5] == 1500 else [0.]*4
            target = [target[0]+d[1]*1.5*dt, target[1]-d[0]*1.5*dt,
                      max(.2,target[2]+d[2]*1.3*dt), target[3]-d[3]*1.5*dt]
            require(max(abs(a-b) for a,b in zip(target,event['position']+[event['yaw']])) < 1e-9, 'RC integration mismatch')
            targets.append(event)
            last_op = event['operation_ns']
    require(activations and len(targets)>30, 'Missing sustained RC activation/output')
    # Decode retained middleware bytes independently of the runtime's decoded copy.
    from rosidl_runtime_py.utilities import get_message
    from rosidl_runtime_py.convert import message_to_ordereddict
    from rclpy.serialization import deserialize_message
    raw = list(lines(root/'rc-dds.jsonl'))
    native = []
    for row in raw:
        message = message_to_ordereddict(deserialize_message(bytes.fromhex(row['cdr_hex']), get_message(row['type'])))
        require(json.dumps(message,sort_keys=True)==json.dumps(row['message'],sort_keys=True), 'CDR differs from decoded evidence')
        if '/in/trajectory_setpoint' in row['topic'] or row['topic']=='/ap/cmd_gps_pose':
            native.append(row)
    require(len(native)>30, 'Missing actual native DDS targets')
    trace = [physical(row) for row in lines(root/'truth.jsonl')]
    require(all(a['time']<b['time'] for a,b in zip(trace,trace[1:])), 'Physical clock not monotonic')
    require(all(math.isfinite(v) for row in trace for v in (*row['position'],*row['velocity'],row['yaw'])), 'Nonfinite truth')
    phases = result['task']['rc']['phases']
    def phase(name, last=False):
        values = [p for p in phases if p['phase']==name]
        require(values, 'Missing phase '+name)
        return values[-1 if last else 0]
    metrics = {}
    if result['scenario'] != 'yaw':
        a,b=phase('movement_begin',True),phase('movement_end',True)
        delta=b['truth']['position'][0]-a['truth']['position'][0]
        require(delta>.3, 'No physical +X RC motion')
        metrics['movement_x_m']=delta
    if result['scenario']=='recenter':
        a,b=phase('hold_begin'),phase('hold_end')
        samples=[row for row in trace if a['truth']['time']<=row['time']<=b['truth']['time']]
        require(samples[-1]['time']-samples[0]['time']>=3.8, 'Insufficient physical hold window')
        speed=max(math.hypot(*row['velocity']) for row in samples)
        drift=max(math.dist(row['position'],samples[0]['position']) for row in samples)
        require(speed<=.25 and drift<=1., 'Physical recenter hold failed')
        metrics.update(hold_speed_mps=speed,hold_drift_m=drift)
    if result['scenario']=='yaw':
        a,b=phase('yaw_begin'),phase('yaw_end')
        delta=math.remainder(b['truth']['yaw']-a['truth']['yaw'],2*math.pi)
        require(delta<-.3, 'No physical negative yaw motion')
        metrics['yaw_delta_rad']=delta
    if result['scenario'] in ('stream-stall','new-takeover'):
        require(any(e['reason']=='rc_input_revoked:input_expired' for e in revokes), 'Missing timeout withdrawal')
        require(any(e['event']=='rc_frame' and e.get('reason')=='retired_stream' for e in events), 'Missing old-stream rejection')
    if result['scenario']=='mode-out':
        require(any(e['reason']=='explicit_native_mode_exit' for e in revokes), 'Missing mode exit withdrawal')
        phase('mode_out_observed')
    if result['scenario']=='new-takeover':
        require(len({e['rc_stream_id'] for e in activations})>=3, 'Missing fresh explicit takeover streams')
        phase('command_handoff')
    require(abs(trace[-1]['position'][2])<.3, 'Physical landing missing')
    return dict(status='pass', scope='RC candidate raw audit; no joint-rate or Full claim',
                stack=result['stack'], scenario=result['scenario'], metrics=metrics,
                raw_cdr_records=len(raw), native_target_records=len(native), integrated_steps=len(targets),
                result_sha256=digest(root/'result.json'), audit_sha256=digest(__file__))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    require(not args.output.exists() and not args.output.resolve().is_relative_to(args.root.resolve()), 'Use fresh external audit output')
    try:
        result=audit(args.root)
    except Exception as error:
        result=dict(status='failed',error=repr(error),audit_sha256=digest(__file__))
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
    return 0 if result['status']=='pass' else 1


if __name__=='__main__': raise SystemExit(main())
